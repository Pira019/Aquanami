package springBoot.demoSpringBoot.services.contrat;

import springBoot.demoSpringBoot.models.UserRole;

public interface UserRoleService {
		void save(UserRole userRole);
}
