package springBoot.demoSpringBoot.services.contrat;

import springBoot.demoSpringBoot.models.Picture;

public interface PictureService {

	Picture save(Picture picture);
	
}
