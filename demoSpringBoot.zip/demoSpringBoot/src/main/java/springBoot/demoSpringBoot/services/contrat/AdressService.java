package springBoot.demoSpringBoot.services.contrat;

import springBoot.demoSpringBoot.models.Adress;

public interface AdressService {

		Adress save(Adress adress);
}
