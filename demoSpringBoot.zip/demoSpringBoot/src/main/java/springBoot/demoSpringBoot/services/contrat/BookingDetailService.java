package springBoot.demoSpringBoot.services.contrat;

import springBoot.demoSpringBoot.models.BookingDetail;

public interface BookingDetailService {
	
	BookingDetail save(BookingDetail bookingDetail);
}
